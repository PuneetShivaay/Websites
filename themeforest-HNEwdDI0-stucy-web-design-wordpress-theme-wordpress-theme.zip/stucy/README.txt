=== Atiframe ===
Contributors: secretlabpw
Tags: two-columns, three-columns, four-columns, left-sidebar, right-sidebar, grid-layout, footer-widgets, full-width-template, sticky-post, blog, photography, portfolio
Requires at least: WordPress 4.3
Tested up to: WordPress 5.3-trunk
Version: 2.0
Requires PHP: 5.6
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

=== Documentation & Support ===
Documentation https://support.secretlab.pw/help-center
For free users we provide bug fixing only
Support provides for paid users https://support.secretlab.pw/
Our paid services like speed optimization, redesign etc https://secretlab.pw/product-category/wordpress-services/