Download and install W3 Total Cache plugin
- Go to Performance > General Settings
- At the end of this page you'll find "Import / Export Settings" section which you can import "w3-total-cache-config.json" file. The mentioned file is available via Package Content Folder > IncreasePageSpeed